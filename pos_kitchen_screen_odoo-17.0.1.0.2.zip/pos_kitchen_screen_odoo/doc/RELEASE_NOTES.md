## Module <pos_kitchen_screen_odoo>

#### 10.01.2024
#### Version 17.0.1.0.0
#### ADD
- Initial commit for Pos Kitchen Screen

#### 27.08.2024
#### Version 17.0.1.0.2
#### BUG FIX
- Fix the issue where the total amount changes to the amount without tax after 
 refreshing the page.
- Fix the issue of creating two records in the backend for a single order.
